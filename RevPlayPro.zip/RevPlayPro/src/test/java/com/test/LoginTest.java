package com.revplay.test;

import static org.junit.Assert.*;
import org.junit.Test;
import com.service.AuthService;

public class LoginTest {

    @Test
    public void testLogin() {
        AuthService auth = new AuthService();
        assertNotNull(auth.login("test@gmail.com", "1234"));
    }
}
