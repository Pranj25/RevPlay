package com.revplay.test;

import org.junit.Test;
import static org.junit.Assert.*;
import com.revplay.service.AuthService;

public class AuthTest {

    @Test
    public void testRegister(){

        AuthService s=new AuthService();
        assertFalse(s.register("","",""));
    }
}
