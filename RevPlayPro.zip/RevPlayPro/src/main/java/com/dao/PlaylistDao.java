package com.revplay.dao;

import com.model.Playlist;
import com.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class PlaylistDao {

	// Create playlist
	public boolean createPlaylist(Playlist playlist) {
		String sql = "INSERT INTO playlists(user_id, name, privacy) VALUES (?, ?, ?)";

		try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {

			ps.setInt(1, playlist.getUserId());
			ps.setString(2, playlist.getName());
			ps.setString(3, playlist.getPrivacy());

			return ps.executeUpdate() > 0;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	// View playlists
	public void viewPlaylists(int userId) {
		String sql = "SELECT * FROM playlists WHERE user_id=?";

		try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {

			ps.setInt(1, userId);
			ResultSet rs = ps.executeQuery();

			System.out.println("\nYour Playlists:");
			while (rs.next()) {
				System.out.println(
						rs.getInt("playlist_id") + " | " + rs.getString("name") + " | " + rs.getString("privacy"));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Delete playlist
	public boolean deletePlaylist(int playlistId) {
		String sql = "DELETE FROM playlists WHERE playlist_id=?";

		try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {

			ps.setInt(1, playlistId);
			return ps.executeUpdate() > 0;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
}
