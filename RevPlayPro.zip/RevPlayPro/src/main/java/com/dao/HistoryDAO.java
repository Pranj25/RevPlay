package com.revplay.dao;

import com.util.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class HistoryDAO {

    // Add history entry
    public void addHistory(int userId, int songId) {
        String sql = "INSERT INTO history(user_id, song_id) VALUES (?, ?)";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, userId);
            ps.setInt(2, songId);
            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // View history
    public void viewHistory(int userId) {
        String sql = """
            SELECT s.title, h.played_time
            FROM history h
            JOIN songs s ON h.song_id = s.song_id
            WHERE h.user_id = ?
            ORDER BY h.played_time DESC
        """;

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();

            System.out.println("\nListening History:");
            while (rs.next()) {
                System.out.println(
                        rs.getString("title") + " | " +
                        rs.getTimestamp("played_time"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
