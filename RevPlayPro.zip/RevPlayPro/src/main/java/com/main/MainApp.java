package com.revplay.main;

import com.revplay.util.DBConnection;
import com.revplay.controller.UserController;
import java.util.Scanner;
import com.revplay.controller.ArtistController;


public class MainApp {
    public static void main(String[] args) {
        DBConnection.getConnection();
        
        UserController controller = new UserController();
        controller.start();
        

        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n=====  REVPLAY =====");
            System.out.println("1. User Login / Register");
            System.out.println("2. Artist Login");
            System.out.println("3. Exit");
            System.out.print("Choose option: ");

            int choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1:
                    UserController userController = new UserController();
                    userController.start();
                    break;

                case 2:
                    ArtistController artistController = new ArtistController();
                    artistController.start();
                    break;

                case 3:
                    System.out.println("Thank you for using RevPlay!");
                    System.exit(0);

                default:
                    System.out.println("Invalid choice");
            }
        }
    }
}
