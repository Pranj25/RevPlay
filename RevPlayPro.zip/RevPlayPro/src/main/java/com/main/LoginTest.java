package com.revplay.main;

import static org.junit.Assert.*;
import org.junit.Test;
import com.service.AuthService;

public class LoginTest {

    @Test
    public void testLogin() {
        AuthService auth = new AuthService();
        assertNotNull(auth.login("pranjal@gmail.com", "1234"));
    }
}
