package com.revplay.service;

import com.dao.UserDao;
import com.model.User;

import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;

public class AuthService {

    private static final Logger logger =
            LogManager.getLogger(AuthService.class);

    private UserDao userDAO = new UserDao();

    // Register User
    public boolean register(String name, String email, String password) {

        if (name == null || email == null || password == null ||
            name.isEmpty() || email.isEmpty() || password.isEmpty()) {

            logger.warn("Registration failed: Empty fields");
            return false;
        }

        User user = new User(name, email, password);

        boolean status = userDAO.registerUser(user);

        if (status) {
            logger.info("User registered successfully: " + email);
        } else {
            logger.error("User registration failed: " + email);
        }

        return status;
    }

    // Login User
    public User login(String email, String password) {

        if (email == null || password == null ||
            email.isEmpty() || password.isEmpty()) {

            logger.warn("Login failed: Empty credentials");
            return null;
        }

        User user = userDAO.loginUser(email, password);

        if (user != null) {
            logger.info("Login successful: " + email);
        } else {
            logger.warn("Login failed: Invalid credentials for " + email);
        }

        return user;
    }
}
