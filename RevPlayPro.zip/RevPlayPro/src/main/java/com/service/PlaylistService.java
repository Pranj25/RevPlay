package com.revplay.service;

import com.dao.PlaylistDao;
import com.model.Playlist;

public class PlaylistService {

    private PlaylistDao playlistDAO = new PlaylistDao();

    public boolean createPlaylist(int userId, String name, String privacy) {
        Playlist playlist = new Playlist(userId, name, privacy);
        return playlistDAO.createPlaylist(playlist);
    }

    public void viewPlaylists(int userId) {
        playlistDAO.viewPlaylists(userId);
    }

    public boolean deletePlaylist(int playlistId) {
        return playlistDAO.deletePlaylist(playlistId);
    }
}
