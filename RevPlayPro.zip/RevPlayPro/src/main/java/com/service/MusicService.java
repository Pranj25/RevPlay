package com.revplay.service;

import com.dao.SongDao;
import com.dao.HistoryDAO;

import java.util.Scanner;

public class MusicService {

    private SongDao songDAO = new SongDao();
    private HistoryDAO historyDAO = new HistoryDAO();
    private Scanner sc = new Scanner(System.in);

    public void viewSongs() {
        songDAO.viewAllSongs();
    }

    public void searchSong(String keyword) {
        songDAO.searchSong(keyword);
    }

    // Simple play (without userId)
    public void playSong(int songId) {
        songDAO.increasePlayCount(songId);
        playerControls();
    }

    // Play with history (RECOMMENDED)
    public void playSong(int userId, int songId) {

        songDAO.increasePlayCount(songId);
        historyDAO.addHistory(userId, songId);

        playerControls();
    }

    // 🎵 Player control logic
    private void playerControls() {

        boolean playing = true;
        System.out.println("▶ Playing song...");

        while (playing) {
            System.out.println("\n--- PLAYER CONTROLS ---");
            System.out.println("1. Pause");
            System.out.println("2. Next");
            System.out.println("3. Repeat");
            System.out.println("4. Stop");
            System.out.print("Choose option: ");

            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("⏸ Song paused");
                    break;

                case 2:
                    System.out.println("⏭ Playing next song ");
                    break;

                case 3:
                    System.out.println("🔁 Repeating current song");
                    break;

                case 4:
                    System.out.println("⏹ Song stopped");
                    playing = false;
                    break;

                default:
                    System.out.println("Invalid option");
            }
        }
    }
}
