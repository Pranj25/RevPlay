package com.revplay.controller;

import com.revplay.model.User;
import com.revplay.service.AuthService;

import java.util.Scanner;

public class AuthController {

    private AuthService service = new AuthService();
    private Scanner sc = new Scanner(System.in);

    public void start(){

        while(true){

            System.out.println("\n===== RevPlay System =====");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.print("Choose: ");

            int ch = sc.nextInt();
            sc.nextLine();

            switch(ch){

                case 1: register(); break;
                case 2: login(); break;
                case 3: System.exit(0);

                default:
                    System.out.println("Invalid choice");
            }
        }
    }

    private void register(){

        System.out.print("Name: ");
        String name = sc.nextLine();

        System.out.print("Email: ");
        String email = sc.nextLine();

        System.out.print("Password: ");
        String pass = sc.nextLine();

        boolean status = service.register(name,email,pass);

        if(status)
            System.out.println("Registration Successful");
        else
            System.out.println("Registration Failed");
    }

    private void login(){

        System.out.print("Email: ");
        String email = sc.nextLine();

        System.out.print("Password: ");
        String pass = sc.nextLine();

        com.model.User u = service.login(email,pass);

        if(u!=null)
            System.out.println("Welcome " + u.getName());
        else
            System.out.println("Invalid Login");
    }
}
