package com.revplay.controller;

import com.dao.ArtistDAO;
import com.model.Artist;

import java.util.Scanner;

public class ArtistController {

	private ArtistDAO artistDAO = new ArtistDAO();
	private Scanner sc = new Scanner(System.in);

	public void start() {

		System.out.println("\n=== ARTIST LOGIN ===");
		System.out.print("Email: ");
		String email = sc.nextLine();

		System.out.print("Password: ");
		String password = sc.nextLine();

		Artist artist = artistDAO.loginArtist(email, password);

		if (artist != null) {
			System.out.println("Login successful!");
			ArtistDashboardController dashboard = new ArtistDashboardController();
			dashboard.showDashboard(artist.getArtistId());
		} else {
			System.out.println("Invalid credentials");
		}
	}
}
