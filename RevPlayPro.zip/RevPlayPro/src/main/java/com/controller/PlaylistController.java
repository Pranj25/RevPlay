package com.revplay.controller;

import com.service.PlaylistService;
import java.util.Scanner;

public class PlaylistController {

	private PlaylistService playlistService = new PlaylistService();
	private Scanner sc = new Scanner(System.in);

	public void playlistMenu(int userId) {

		while (true) {
			System.out.println("\n=== PLAYLIST MENU ===");
			System.out.println("1. Create Playlist");
			System.out.println("2. View My Playlists");
			System.out.println("3. Delete Playlist");
			System.out.println("4. Back");
			System.out.print("Choose option: ");

			int choice = sc.nextInt();
			sc.nextLine();

			switch (choice) {
			case 1:
				System.out.print("Enter playlist name: ");
				String name = sc.nextLine();

				System.out.print("Privacy (public/private): ");
				String privacy = sc.nextLine();

				if (playlistService.createPlaylist(userId, name, privacy)) {
					System.out.println("Playlist created successfully!");
				} else {
					System.out.println("Failed to create playlist.");
				}
				break;

			case 2:
				playlistService.viewPlaylists(userId);
				break;

			case 3:
				System.out.print("Enter playlist ID to delete: ");
				int pid = sc.nextInt();

				if (playlistService.deletePlaylist(pid)) {
					System.out.println("Playlist deleted.");
				} else {
					System.out.println("Delete failed.");
				}
				break;

			case 4:
				return;

			default:
				System.out.println("Invalid option");
			}
		}
	}
}
