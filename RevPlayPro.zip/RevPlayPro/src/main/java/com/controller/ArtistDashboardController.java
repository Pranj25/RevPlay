package com.revplay.controller;

import com.dao.AlbumDAO;
import com.dao.ArtistSongDAO;

import java.util.Scanner;

public class ArtistDashboardController {

	private Scanner sc = new Scanner(System.in);
	private AlbumDAO albumDAO = new AlbumDAO();
	private ArtistSongDAO songDAO = new ArtistSongDAO();

	public void showDashboard(int artistId) {

		while (true) {
			System.out.println("\n=== ARTIST DASHBOARD ===");
			System.out.println("1. Create Album");
			System.out.println("2. Upload Song");
			System.out.println("3. View My Songs");
			System.out.println("4. Logout");
			System.out.print("Choose option: ");

			int choice = sc.nextInt();
			sc.nextLine();

			switch (choice) {
			case 1:
				System.out.print("Enter album name: ");
				String album = sc.nextLine();

				if (albumDAO.createAlbum(artistId, album)) {
					System.out.println("Album created successfully!");
				}
				break;

			case 2:
				System.out.print("Song title: ");
				String title = sc.nextLine();

				System.out.print("Genre: ");
				String genre = sc.nextLine();

				System.out.print("Duration (seconds): ");
				int duration = sc.nextInt();

				System.out.print("Album ID: ");
				int albumId = sc.nextInt();

				if (songDAO.uploadSong(title, genre, duration, artistId, albumId)) {
					System.out.println("Song uploaded!");
				}
				break;

			case 3:
				songDAO.viewMySongs(artistId);
				break;

			case 4:
				return;

			default:
				System.out.println("Invalid option");
			}
		}
	}
}
