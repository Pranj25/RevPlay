package com.revplay.controller;

import com.model.User;
import com.service.AuthService;
import com.controller.UserDashboardController;


import java.util.Scanner;

public class UserController {

	private AuthService authService = new AuthService();
	private Scanner sc = new Scanner(System.in);

	public void start() {
		while (true) {
			System.out.println("\n=== RevPlay ===");
			System.out.println("1. Register");
			System.out.println("2. Login");
			System.out.println("3. Exit");
			System.out.print("Choose option: ");

			int choice = sc.nextInt();
			sc.nextLine();

			switch (choice) {
			case 1:
				register();
				break;
			case 2:
				login();
				break;
			case 3:
				System.out.println("Thank you for using RevPlay!");
				return;
			default:
				System.out.println("Invalid choice");
			}
		}
	}

	private void register() {
		System.out.print("Enter Name: ");
		String name = sc.nextLine();

		System.out.print("Enter Email: ");
		String email = sc.nextLine();

		System.out.print("Enter Password: ");
		String password = sc.nextLine();

		if (authService.register(name, email, password)) {
			System.out.println("Registration successful!");
		} else {
			System.out.println("Registration failed!");
		}
	}

	private void login() {
		System.out.print("Enter Email: ");
		String email = sc.nextLine();

		System.out.print("Enter Password: ");
		String password = sc.nextLine();

		User user = authService.login(email, password);

		if (user != null) {
			System.out.println("Login successful!");
			UserDashboardController dashboard = new UserDashboardController();
			dashboard.showDashboard(user.getUserId(), user.getName());
		} else {
			System.out.println("Invalid credentials");
		}
	}
}
