package com.revplay.controller;

import java.util.Scanner;
import com.controller.PlaylistController;
import com.controller.SongController;
import com.controller.FavoriteController;
import com.dao.HistoryDAO;


public class UserDashboardController {

    private Scanner sc = new Scanner(System.in);

    public void showDashboard(int userId,String userName) {

        while (true) {
            System.out.println("\n===== USER DASHBOARD =====");
            System.out.println("Welcome, " + userName);
            System.out.println("1. Search Songs");
            System.out.println("2. Play Song");
            System.out.println("3. My Playlists");
            System.out.println("4. Favorites");
            System.out.println("5. Listening History");
            System.out.println("6. Logout");
            System.out.print("Choose option: ");

            int choice = sc.nextInt();

            switch (choice) {
            case 1:
            case 2:
                SongController sc = new SongController();
                sc.songMenu();
                break;

                case 3:
                    PlaylistController pc = new PlaylistController();
                    pc.playlistMenu(userId);
                    break;

                case 4:
                    FavoriteController fc = new FavoriteController();
                    fc.favoriteMenu(userId);
                    break;

                case 5:
                    HistoryDAO hd = new HistoryDAO();
                    hd.viewHistory(userId);
                    break;

                case 6:
                    System.out.println("Logged out successfully!");
                    return;

                default:
                    System.out.println("Invalid choice");
            }
        }
    }
}
