package com.revplay.controller;

import com.dao.FavouriteDAO;

import java.util.Scanner;

public class FavoriteController {

    private FavouriteDAO favoriteDAO = new FavouriteDAO();
    private Scanner sc = new Scanner(System.in);

    public void favoriteMenu(int userId) {

        while (true) {
            System.out.println("\n=== FAVORITES MENU ===");
            System.out.println("1. Add to Favorites");
            System.out.println("2. View Favorites");
            System.out.println("3. Back");
            System.out.print("Choose option: ");

            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter Song ID: ");
                    int songId = sc.nextInt();

                    if (favoriteDAO.addToFavorites(userId, songId)) {
                        System.out.println("Added to favorites!");
                    } else {
                        System.out.println("Failed to add.");
                    }
                    break;

                case 2:
                    favoriteDAO.viewFavorites(userId);
                    break;

                case 3:
                    return;

                default:
                    System.out.println("Invalid option");
            }
        }
    }
}
