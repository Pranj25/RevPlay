package com.dao;

import com.model.Song;
import com.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class SongDao {

    // View all songs
    public void viewAllSongs() {
        String sql = "SELECT * FROM songs";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            System.out.println("\nAvailable Songs:");
            while (rs.next()) {
                System.out.println(
                        rs.getInt("song_id") + " | " +
                        rs.getString("title") + " | " +
                        rs.getString("genre"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Search song by title
    public void searchSong(String keyword) {
        String sql = "SELECT * FROM songs WHERE title LIKE ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, "%" + keyword + "%");
            ResultSet rs = ps.executeQuery();

            System.out.println("\nSearch Results:");
            while (rs.next()) {
                System.out.println(
                        rs.getInt("song_id") + " | " +
                        rs.getString("title") + " | " +
                        rs.getString("genre"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Increment play count
    public void increasePlayCount(int songId) {
        String sql = "UPDATE songs SET play_count = play_count + 1 WHERE song_id=?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, songId);
            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
