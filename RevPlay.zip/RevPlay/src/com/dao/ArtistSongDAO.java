package com.dao;

import com.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ArtistSongDAO {

	public boolean uploadSong(String title, String genre, int duration, int artistId, int albumId) {

		String sql = """
				    INSERT INTO songs(title, genre, duration, artist_id, album_id)
				    VALUES (?, ?, ?, ?, ?)
				""";

		try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {

			ps.setString(1, title);
			ps.setString(2, genre);
			ps.setInt(3, duration);
			ps.setInt(4, artistId);
			ps.setInt(5, albumId);

			return ps.executeUpdate() > 0;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	// View artist songs with play count
	public void viewMySongs(int artistId) {
		String sql = "SELECT title, play_count FROM songs WHERE artist_id=?";

		try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {

			ps.setInt(1, artistId);
			ResultSet rs = ps.executeQuery();

			System.out.println("\nMy Songs:");
			while (rs.next()) {
				System.out.println(rs.getString("title") + " | Plays: " + rs.getInt("play_count"));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
