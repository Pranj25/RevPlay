package com.dao;

import com.model.Artist;
import com.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ArtistDAO {

	// Register artist
	public boolean registerArtist(Artist artist) {
		String sql = "INSERT INTO artists(email, password, genre, bio) VALUES (?, ?, ?, ?)";

		try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {

			ps.setString(1, artist.getEmail());
			ps.setString(2, artist.getPassword());
			ps.setString(3, artist.getGenre());
			ps.setString(4, artist.getBio());

			return ps.executeUpdate() > 0;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	// Login artist
	public Artist loginArtist(String email, String password) {
		Artist artist = null;
		String sql = "SELECT * FROM artists WHERE email=? AND password=?";

		try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {

			ps.setString(1, email);
			ps.setString(2, password);

			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				artist = new Artist();
				artist.setArtistId(rs.getInt("artist_id"));
				artist.setEmail(rs.getString("email"));
				artist.setGenre(rs.getString("genre"));
				artist.setBio(rs.getString("bio"));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return artist;
	}
}
