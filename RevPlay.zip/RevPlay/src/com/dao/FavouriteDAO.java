package com.dao;

import com.util.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class FavouriteDAO {

    // Add to favorites
    public boolean addToFavorites(int userId, int songId) {
        String sql = "INSERT INTO favorites(user_id, song_id) VALUES (?, ?)";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, userId);
            ps.setInt(2, songId);
            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // View favorites
    public void viewFavorites(int userId) {
        String sql = """
            SELECT s.song_id, s.title, s.genre
            FROM favorites f
            JOIN songs s ON f.song_id = s.song_id
            WHERE f.user_id = ?
        """;

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();

            System.out.println("\nYour Favorite Songs:");
            while (rs.next()) {
                System.out.println(
                        rs.getInt("song_id") + " | " +
                        rs.getString("title") + " | " +
                        rs.getString("genre"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
