package com.dao;

import com.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class AlbumDAO {

	public boolean createAlbum(int artistId, String albumName) {
		String sql = "INSERT INTO albums(album_name, artist_id) VALUES (?, ?)";

		try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {

			ps.setString(1, albumName);
			ps.setInt(2, artistId);
			return ps.executeUpdate() > 0;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
}
