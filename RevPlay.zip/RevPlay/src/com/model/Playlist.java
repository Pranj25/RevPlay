package com.model;

public class Playlist {
    private int playlistId;
    private int userId;
    private String name;
    private String privacy;

    public Playlist() {}

    public Playlist(int userId, String name, String privacy) {
        this.userId = userId;
        this.name = name;
        this.privacy = privacy;
    }

    public int getPlaylistId() {
        return playlistId;
    }

    public void setPlaylistId(int playlistId) {
        this.playlistId = playlistId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public String getPrivacy() {
        return privacy;
    }
}
