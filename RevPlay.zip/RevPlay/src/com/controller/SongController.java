package com.controller;

import com.service.MusicService;

import java.util.Scanner;

public class SongController {

	private MusicService musicService = new MusicService();
	private Scanner sc = new Scanner(System.in);

	public void songMenu() {

		while (true) {
			System.out.println("\n=== SONG MENU ===");
			System.out.println("1. View All Songs");
			System.out.println("2. Search Song");
			System.out.println("3. Play Song");
			System.out.println("4. Back");
			System.out.print("Choose option: ");

			int choice = sc.nextInt();
			sc.nextLine();

			switch (choice) {
			case 1:
				musicService.viewSongs();
				break;

			case 2:
				System.out.print("Enter song name: ");
				String keyword = sc.nextLine();
				musicService.searchSong(keyword);
				break;

			case 3:
				System.out.print("Enter Song ID to play: ");
				int songId = sc.nextInt();
				musicService.playSong(songId);
				break;

			case 4:
				return;

			default:
				System.out.println("Invalid option");
			}
		}
	}
}
