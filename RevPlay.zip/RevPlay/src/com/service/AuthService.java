package com.service;

import com.dao.UserDao;
import com.model.User;

public class AuthService {

    private UserDao userDAO = new UserDao();

    public boolean register(String name, String email, String password) {
        User user = new User(name, email, password);
        return userDAO.registerUser(user);
    }

    public User login(String email, String password) {
        return userDAO.loginUser(email, password);
    }
}
