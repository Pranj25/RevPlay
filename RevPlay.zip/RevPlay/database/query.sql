create database revplay_db;
use revplay_db;

create table users
( user_id int auto_increment primary key,
name varchar(255),
email varchar(255) unique,
password varchar(255)
);

create table artists(
artist_id int auto_increment primary key,
email varchar(255) unique not null,
password varchar(255) not null,
genre varchar(255),
bio text
);

CREATE TABLE albums (
    album_id INT AUTO_INCREMENT PRIMARY KEY,
    album_name VARCHAR(100) NOT NULL,
    artist_id INT,
    release_date DATE,
    FOREIGN KEY (artist_id) REFERENCES artists(artist_id)
);

CREATE TABLE songs (
    song_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    genre VARCHAR(50),
    duration INT,
    artist_id INT,
    album_id INT,
    play_count INT DEFAULT 0,
    FOREIGN KEY (artist_id) REFERENCES artists(artist_id),
    FOREIGN KEY (album_id) REFERENCES albums(album_id)
);

CREATE TABLE playlists (
    playlist_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    name VARCHAR(100) NOT NULL,
    privacy VARCHAR(10) CHECK (privacy IN ('public','private')),
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

CREATE TABLE playlist_songs (
    playlist_id INT,
    song_id INT,
    FOREIGN KEY (playlist_id) REFERENCES playlists(playlist_id),
    FOREIGN KEY (song_id) REFERENCES songs(song_id)
);

CREATE TABLE favorites (
    user_id INT,
    song_id INT,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (song_id) REFERENCES songs(song_id)
);

CREATE TABLE history (
    user_id INT,
    song_id INT,
    played_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (song_id) REFERENCES songs(song_id)
);

SHOW TABLES;

INSERT INTO users (name, email, password)
VALUES ('Pranjal', 'pranjal@gmail.com', '1234');

INSERT INTO artists (email, password, genre)
VALUES ('artist@gmail.com', 'abcd', 'Pop');

select * from users;
SELECT play_count FROM songs;

INSERT INTO artists (email, password, genre, bio)
VALUES
('arijit@gmail.com', '1234', 'Romantic', 'Indian playback singer'),
('atif@gmail.com', '1234', 'Melody', 'Pakistani playback singer'),
('imagine@gmail.com', '1234', 'Pop', 'International pop band');

INSERT INTO albums (album_name, artist_id, release_date)
VALUES
('Romantic Hits', 1, '2020-01-01'),
('Soulful Songs', 2, '2019-06-10'),
('Pop Anthems', 3, '2018-03-20');

INSERT INTO songs (title, genre, duration, artist_id, album_id)
VALUES
('Tum Hi Ho', 'Romantic', 280, 1, 1),
('Channa Mereya', 'Romantic', 300, 1, 1),
('Jeena Jeena', 'Melody', 250, 2, 2),
('Tera Hone Laga Hoon', 'Melody', 260, 2, 2),
('Believer', 'Pop', 210, 3, 3),
('Thunder', 'Pop', 205, 3, 3);

INSERT INTO users (name, email, password)
VALUES
('Gayatri', 'gayatri@gmail.com', '8421'),
('Archana', 'archana@gmail.com', '9421'),
('Sneha', 'sneha@gmail.com', '7777'),
('Pooja','pooja@gmail.com','8888');

USE revplay_db;
SELECT * FROM users;

INSERT INTO playlists (user_id, name, privacy)
VALUES
(1, 'My Favorites', 'private'),
(3, 'Workout Songs', 'public'),
(4, 'Chill Vibes', 'private');

SELECT * FROM playlists;

INSERT INTO playlist_songs (playlist_id, song_id)
VALUES
(4, 1),
(4, 2),
(5, 5),
(5, 6),
(6, 3);

INSERT INTO favorites (user_id, song_id)
VALUES
(1, 1),
(1, 5),
(4, 3),
(3, 6);

INSERT INTO history (user_id, song_id)
VALUES
(1, 1),
(1, 2),
(4, 3),
(3, 6);

SELECT title, play_count FROM songs;

SELECT * FROM users;
SELECT * FROM artists;
SELECT * FROM albums;
SELECT * FROM songs;
SELECT * FROM playlists;
SELECT * FROM playlist_songs;
SELECT * FROM favorites;
SELECT * FROM history;

SELECT s.song_id, s.title, a.email AS artist
FROM songs s
JOIN artists a ON s.artist_id = a.artist_id;

SELECT p.playlist_id, p.name, u.name AS user_name
FROM playlists p
JOIN users u ON p.user_id = u.user_id;

SELECT p.name AS playlist_name, s.title AS song_title
FROM playlist_songs ps
JOIN playlists p ON ps.playlist_id = p.playlist_id
JOIN songs s ON ps.song_id = s.song_id;

SELECT u.name AS user_name, s.title AS song
FROM favorites f
JOIN users u ON f.user_id = u.user_id
JOIN songs s ON f.song_id = s.song_id;

SELECT u.name AS user_name, s.title AS song, h.played_time
FROM history h
JOIN users u ON h.user_id = u.user_id
JOIN songs s ON h.song_id = s.song_id
ORDER BY h.played_time DESC;

SELECT u.name AS user_name, s.title AS song, h.played_time
FROM history h
JOIN users u ON h.user_id = u.user_id
JOIN songs s ON h.song_id = s.song_id
ORDER BY h.played_time DESC;

